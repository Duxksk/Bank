
package com.junwoofox.browser

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.mozilla.geckoview.*

class MainActivity : AppCompatActivity() {

    private lateinit var geckoView: GeckoView
    private lateinit var urlBar: EditText
    private lateinit var geckoRuntime: GeckoRuntime

    private val historyList = mutableListOf<String>()
    private val bookmarks = mutableSetOf<String>()

    private var incognitoMode = false

    private val tabs = mutableListOf<GeckoSession>()
    private var currentTabIndex = 0
    private val maxTabs = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        geckoView = findViewById(R.id.geckoView)
        urlBar = findViewById(R.id.urlBar)

        geckoRuntime = GeckoRuntime.create(this)

        createNewTab("https://google.com")

        findViewById<Button>(R.id.btnSearch).setOnClickListener {
            val query = urlBar.text.toString()
            val url = if (query.startsWith("http")) query else "https://www.google.com/search?q=$query"
            loadUrl(url)
        }

        findViewById<Button>(R.id.btnBack).setOnClickListener { currentTab().goBack() }
        findViewById<Button>(R.id.btnForward).setOnClickListener { currentTab().goForward() }
        findViewById<Button>(R.id.btnReload).setOnClickListener { currentTab().reload() }
        findViewById<Button>(R.id.btnHome).setOnClickListener { loadUrl("https://google.com") }

        findViewById<Button>(R.id.btnBookmark).setOnClickListener {
            val cur = urlBar.text.toString()
            if (cur.isNotBlank()) {
                bookmarks.add(cur)
                Toast.makeText(this, "Bookmarked!", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btnHistory).setOnClickListener {
            Toast.makeText(this, historyList.joinToString("\n"), Toast.LENGTH_LONG).show()
        }

        findViewById<Button>(R.id.btnIncognito).setOnClickListener {
            incognitoMode = !incognitoMode
            Toast.makeText(this, if (incognitoMode) "Incognito ON" else "Incognito OFF", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnNewTab).setOnClickListener {
            if (tabs.size < maxTabs) {
                createNewTab("https://google.com")
                Toast.makeText(this, "New Tab (${tabs.size})", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Max 100 tabs reached", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btnNextTab).setOnClickListener {
            switchTab((currentTabIndex + 1) % tabs.size)
        }

        findViewById<Button>(R.id.btnPrevTab).setOnClickListener {
            switchTab((currentTabIndex - 1 + tabs.size) % tabs.size)
        }
    }

    private fun currentTab(): GeckoSession = tabs[currentTabIndex]

    private fun createNewTab(url: String) {
        val settings = GeckoRuntimeSettings.Builder()
            .usePrivateMode(incognitoMode)
            .build()

        geckoRuntime = GeckoRuntime.create(this, settings)

        val session = GeckoSession()

        session.webRequestDelegate = object : GeckoSession.WebRequestDelegate {
            override fun onBeforeRequest(session: GeckoSession, req: WebRequest)
                    : GeckoResult<WebRequest.Response?>? {
                val u = req.uri.toString()
                if (u.contains("ads") || u.contains("doubleclick") || u.contains("track"))
                    return GeckoResult.fromValue(WebRequest.Response(WebRequest.Action.CANCEL))
                return null
            }
        }

        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStop(session: GeckoSession, success: Boolean) {
                val url = session.currentUri
                if (!incognitoMode && url != null) historyList.add(url)
                urlBar.setText(url)
            }
        }

        session.open(geckoRuntime)
        tabs.add(session)
        currentTabIndex = tabs.size - 1
        geckoView.setSession(session)
        session.loadUri(url)
    }

    private fun switchTab(index: Int) {
        currentTabIndex = index
        geckoView.setSession(currentTab())
        urlBar.setText(currentTab().currentUri)
    }

    private fun loadUrl(url: String) {
        currentTab().loadUri(url)
    }
}
